const html = `
        <div id="contenedor-digito">
            <div id="central-superior" class="borde"></div>
            <div id="izqui-superior" class="borde"></div>
            <div id="dere-superior" class="borde"></div>
            <div id="central" class="borde"></div>
            <div id="izqui-inferior" class="borde"></div>
            <div id="dere-inferior" class="borde"></div>
            <div id="central-inferior" class="borde"></div>
        </div>
        `;
export default html;